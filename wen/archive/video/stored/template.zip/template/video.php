<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<title>Muller/Kluge - Conversations between Heiner Muller and Alexander Kluge :: Cornell University Library</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta http-equiv="Content-Language" content="en-us" />
	<meta name="robots" content="all" />
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
	<link rel="stylesheet" type="text/css" media="screen" href="styles/screen.css" />
	<script language="JavaScript" type="text/javascript">
		<!--
		// -----------------------------------------------------------------------------
		// Globals
		// Major version of Flash required
		var requiredMajorVersion = 8;
		// Minor version of Flash required
		var requiredMinorVersion = 0;
		// Revision of Flash required
		var requiredRevision = 0;
		// the version of javascript supported
		var jsVersion = 1.0;
		// -----------------------------------------------------------------------------
		// -->
		</script>
		<script language="VBScript" type="text/vbscript">
		<!-- // Visual basic helper required to detect Flash Player ActiveX control version information
		Function VBGetSwfVer(i)
		  on error resume next
		  Dim swControl, swVersion
		  swVersion = 0
		  
		  set swControl = CreateObject("ShockwaveFlash.ShockwaveFlash." + CStr(i))
		  if (IsObject(swControl)) then
			swVersion = swControl.GetVariable("$version")
		  end if
		  VBGetSwfVer = swVersion
		End Function
		// -->
		</script>
		<script language="JavaScript1.1" type="text/javascript">
		<!-- // Detect Client Browser type
		var isIE  = (navigator.appVersion.indexOf("MSIE") != -1) ? true : false;
		var isWin = (navigator.appVersion.toLowerCase().indexOf("win") != -1) ? true : false;
		var isOpera = (navigator.userAgent.indexOf("Opera") != -1) ? true : false;
		jsVersion = 1.1;
		// JavaScript helper required to detect Flash Player PlugIn version information
		function JSGetSwfVer(i){
			// NS/Opera version >= 3 check for Flash plugin in plugin array
			if (navigator.plugins != null && navigator.plugins.length > 0) {
				if (navigator.plugins["Shockwave Flash 2.0"] || navigator.plugins["Shockwave Flash"]) {
					var swVer2 = navigator.plugins["Shockwave Flash 2.0"] ? " 2.0" : "";
					var flashDescription = navigator.plugins["Shockwave Flash" + swVer2].description;
					descArray = flashDescription.split(" ");
					tempArrayMajor = descArray[2].split(".");
					versionMajor = tempArrayMajor[0];
					versionMinor = tempArrayMajor[1];
					if ( descArray[3] != "" ) {
						tempArrayMinor = descArray[3].split("r");
					} else {
						tempArrayMinor = descArray[4].split("r");
					}
					versionRevision = tempArrayMinor[1] > 0 ? tempArrayMinor[1] : 0;
					flashVer = versionMajor + "." + versionMinor + "." + versionRevision;
				} else {
					flashVer = -1;
				}
			}
			// MSN/WebTV 2.6 supports Flash 4
			else if (navigator.userAgent.toLowerCase().indexOf("webtv/2.6") != -1) flashVer = 4;
			// WebTV 2.5 supports Flash 3
			else if (navigator.userAgent.toLowerCase().indexOf("webtv/2.5") != -1) flashVer = 3;
			// older WebTV supports Flash 2
			else if (navigator.userAgent.toLowerCase().indexOf("webtv") != -1) flashVer = 2;
			// Can't detect in all other cases
			else {
				
				flashVer = -1;
			}
			return flashVer;
		} 
		// If called with no parameters this function returns a floating point value 
		// which should be the version of the Flash Player or 0.0 
		// ex: Flash Player 7r14 returns 7.14
		// If called with reqMajorVer, reqMinorVer, reqRevision returns true if that version or greater is available
		function DetectFlashVer(reqMajorVer, reqMinorVer, reqRevision) 
		{
			reqVer = parseFloat(reqMajorVer + "." + reqRevision);
			// loop backwards through the versions until we find the newest version	
			for (i=25;i>0;i--) {	
				if (isIE && isWin && !isOpera) {
					versionStr = VBGetSwfVer(i);
				} else {
					versionStr = JSGetSwfVer(i);		
				}
				if (versionStr == -1 ) { 
					return false;
				} else if (versionStr != 0) {
					if(isIE && isWin && !isOpera) {
						tempArray         = versionStr.split(" ");
						tempString        = tempArray[1];
						versionArray      = tempString .split(",");				
					} else {
						versionArray      = versionStr.split(".");
					}
					versionMajor      = versionArray[0];
					versionMinor      = versionArray[1];
					versionRevision   = versionArray[2];
					
					versionString     = versionMajor + "." + versionRevision;   // 7.0r24 == 7.24
					versionNum        = parseFloat(versionString);
					// is the major.revision >= requested major.revision AND the minor version >= requested minor
					if ( (versionMajor > reqMajorVer) && (versionNum >= reqVer) ) {
						return true;
					} else {
						return ((versionNum >= reqVer && versionMinor >= reqMinorVer) ? true : false );	
					}
				}
			}	
			return (reqVer ? false : 0.0);
		}
		// -->
		</script>

	
</head>

<body>

<div id="cu-identity">
	<?php include('inc/cuidentity.php'); ?>
</div>

<hr />

<div id="header">
	<div id="identity">
	    <?php include('inc/banner.php'); ?>		
	</div>	
</div>

<hr />


<div id="wrap">

<div id="content">

	<div id="main">

		<div id="navigation">
			<?php include('inc/navigation.php'); ?>	
		</div>

		
		<div id="main-content">
	
			<div id="main-text-650">
				<div id="breadcrumbs">
					<a href="index.php" title="Home">Home</a> > <a href="videos.php" title="Videos">Videos</a> > Queen of Hearts on Judgment Day
				</div>
				
			<div id="video">
				<div id="video-tabs">
					<ul>
						<li><a href="video112.php" title="Video" class="tab-on">Video Main</a></li>
						<li><a href="video112_exp.php" title="Expanded Video">Expanded Video</a></li>
						<li><a href="video112_annotations.php" title="Annotations">Annotations</a></li>
					</ul>
				</div>
				
				<div id="video-content">
					<div id="flash-content">
						<div id="column1">
							<div id="video-title">
								<h5>Queen of Hearts on Judgment Day</h5>
								<p>Broadcast Date 09.10.1995</p>
								<p>Duration 24:11:00</p>	
							</div>
							<div id="controls-wrapper">
								<div id="controls-content">
									<p><a href="#" title="Play Video" class="bold">Play Full Video</a></p>
									<p><a href="video112_exp.html" class="bold">View Expanded Video</a> (640 x 480)</p>
									<ul>
										<li class="list-header">Segments</li>	
										<li><a href="#" title="Chapter">Death and the blindness of the will in life</a></li>
										<li><a href="#" title="Chapter">What is patriotism?</a></li>
										<li><a href="#" title="Chapter">Opera and Realism</a></li>
									</ul>						
								</div>
							</div>
							<ul>
								<li><a href="transcript_en14.html" title="Transcript" target="_blank">English Transcript</a></li>
								<li><a href="#" title="German transcript">German Transcript</a></li>
							</ul>
						</div>
							
						<div id="column2">
							<script language="JavaScript" type="text/javascript">
							<!-- 
							var hasRightVersion = DetectFlashVer(requiredMajorVersion, requiredMinorVersion, requiredRevision);
							if(hasRightVersion) {  // if we've detected an acceptable version
								var oeTags = '<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'
								+ 'width="340" height="345"'
								+ 'codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab">'
								+ '<param name="movie" value="captionPlayer9.swf" /><param name="quality" value="high" /><param name="bgcolor" value="#000000" />'
								+ '<param name="FlashVars" value="fvLang=english&fvFilm=112" />'
								+ '<embed src="captionPlayer9.swf" FlashVars="fvLang=english&fvFilm=112" quality="high" bgcolor="#000000" '
								+ 'width="340" height="345" name="captionPlayer8" align="middle"'
								+ 'play="true"'
								+ 'loop="false"'
								+ 'quality="high"'
								+ 'allowScriptAccess="sameDomain"'
								+ 'type="application/x-shockwave-flash"'
								+ 'pluginspage="http://www.macromedia.com/go/getflashplayer">'
								+ '<\/embed>'
								+ '<\/object>';
								document.write(oeTags);   // embed the flash movie
							  } else {  // flash is too old or we can't detect the plugin
								var alternateContent = 'Alternate HTML content should be placed here.'
								+ 'This content requires the Macromedia Flash Player.'
								+ '<a href=http://www.macromedia.com/go/getflash/>Get Flash</a>';
								document.write(alternateContent);  // insert non-flash content
							  }
							// -->
							</script>
							<noscript>
								// Provide alternate content for browsers that do not support scripting
								// or for those that have scripting disabled.
								Alternate HTML content should be placed here. This content requires the Macromedia Flash Player.
								<a href="http://www.macromedia.com/go/getflash/">Get Flash</a>  	
							</noscript>						
						</div>
					</div>
					<div id="metadata">
						<div class="metadata-content">
							<dl>
								<dt>Description</dt>
								<dd>The horizon of this conversation is marked by M�ller's personal memories, reflections about ongoing themes in 
								his work, thoughts about his current production and the nearness to death that has been brought by his illness. 
								M�ller's thoughts circle around the alliance between "blindness" and power, which shows itself in different ways 
								in the Greek heroic figures, but which is also present in his own literary production. The concept of realism that 
								Kluge brings into the discussion is inflected accordingly by M�ller.  He claims that reality can only be seen when 
								it is dismantled into individual parts; "submissiveness" to so-called reality is a false position. The 
								unconventional, bold ideas that follow about how the opera can be used to sabotage representational realism are 
								linked to M�ller's experiences as the Wagner director in Bayreuth in the same year.  � Kluge asks M�ller about 
								the theme "patriotism," taking a <span class="italic">Spiegel</span> article which the poem "Queen of Hearts on Judgment 
								Day" refers to as a point of departure. However, M�ller does not take up the references to metaphors from his own texts &#8212;
								the French revolution as a stranded ship &#8212; but rather he closes the interview with a joke, whose punch line connects 
								alcoholism and patriotism. Of all of the conversations, this one is the most associative. It jumps from one theme to 
								another and circles around the above-named subjects rather than treating them one after another. The division into 
								sections distorts this.</dd>
							</dl>
						</div>
				</div>

				

			</div>
			
			
			
		</div>

	
		
	</div>
</div>
</div>

<hr />

<div id="footer">
	<?php include('inc/footer.php'); ?>
</div>

</body>
</html>