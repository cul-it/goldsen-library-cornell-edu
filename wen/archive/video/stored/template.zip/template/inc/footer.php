<div id="footer-content">
		&copy;2006 <a href="http://www.cornell.edu/" title="Cornell University Library home page">Cornell University Library</a> :: <a href="credits.php" title="Project Credits">Credits</a> :: Contact
		<p>Made available by the <a href="http://facultygrants.library.cornell.edu/" title="Faculty Grants web site">Faculty Grants for Digital Libraries: Advancing E-Scholarship</a> program.</p>
	</div>