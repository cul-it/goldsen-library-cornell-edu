<div id="cu-logo"> <a id="insignia-link" href="http://www.cornell.edu/"><img src="images/layout/library_gray.gif" alt="Cornell University" width="283" height="75" border="0" /></a> 
    <div id="unit-signature-links"> <a id="cornell-link" href="http://www.cornell.edu/">Cornell 
      University</a> <a id="unit-link" href="http://www.library.cornell.edu/">Search Library</a> 
    </div><img src="images/button_resources.gif" alt="Resources" />
	</div>
		<div id="search-form">
		<form action="#" method="post" enctype="application/x-www-form-urlencoded">
			<div id="search-input">
				<label for="search-form-query">SEARCH:</label>
				<input type="text" id="search-form-query" name="query" value="" size="20" />
				<input type="submit" id="search-form-submit" name="submit" value="go" />
			</div>

			<div id="search-filters">
					<input type="radio" id="search-filters1" name="target" value="unit" checked="checked" />
					<label for="search-filters1">This site</label>
				
					<input type="radio" id="search-filters2" name="target" value="cornell" />
					<label for="search-filters2">Cornell</label>
					
					<a href="#">more options</a>
			</div>	
		</form>
	</div>