
			<ul>
				<li><a href="index.php" title="Home"><img src="../images/layout/arrows/right_red.gif" alt=" ">  Home</a></li>
				<li><a href="videos.php" title="Videos"><img src="../images/layout/arrows/right_red.gif" alt=" "> Videos</a></li>
				<li><a href="themes.php" title="Themes"><img src="../images/layout/arrows/right_red.gif" alt=" "> Themes</a></li>
				<li><a href="resources.php" title="Resources"><img src="../images/layout/arrows/right_red.gif" alt=" "> Resources</a></li>
				<li><a href="about.php" title="About"><img src="../images/layout/arrows/right_red.gif" alt=" "> About</a></li>
				<li><a href="help.php" title="Help"><img src="../images/layout/arrows/right_red.gif" alt=" "> Help</a></li>
			</ul>
