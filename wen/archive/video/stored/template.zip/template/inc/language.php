<div class="secondary-section">
	<div id="language">
		<h6>Select Language</h6>
		<a href="#" title="English">English</a> | <a href="#" title="German">German</a>
	</div>
</div>